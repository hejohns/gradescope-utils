#!/usr/bin/env bash

zip AG *
